require("./all/module.js")

//========== Setting Owner ==========//
global.owner = "6285184105776"
global.namaowner = "RELL STR" 

//======== Setting Bot & Link ========//
global.namabot = "Bot by RELL STR" 
global.idsaluran = "-"
global.linkgc = '-'
global.packname = "Bot WhatsApp B̷y̷ RELL"
global.author = "Bot RELL"
global.linksaluran = "https://whatsapp.com/channel/0029Vap3ToiEawdvygXUwM3F"
global.linkgc1 = "https://chat.whatsapp.com/FAlptNFdB3m0JkMDXdMWm6"
global.linkgc2 = "https://chat.whatsapp.com/FAlptNFdB3m0JkMDXdMWm6"
//========== Setting Event ==========//
global.welcome = false
global.autoread = false
global.anticall = false

//==== Waktu Jeda Jpm & Pushkon ====//
global.delaypushkontak = 1500
global.delayjpm = 8000

//========= Setting Url Foto =========//
global.image = "https://qu.ax/vwTn.jpeg"

//========== Setting Panell ==========//
global.egg = "15"
global.loc = "1"
global.domain = ""
global.apikey = "" //PTLA
global.capikey = "" //PTLC

//========= Setting Payment =========//
//Kalo Gak Ada Isi Aja jadi false
global.dana = "085263442218"
global.gopay = false
global.ovo = false
global.qris = false


//=========== Api Domain ===========//
global.zone1 = "-"
global.apitoken1 = "-"
global.tld1 = "-"
//========== Api Domain 2 ==========//
global.zone2 = "-";
global.apitoken2 = "-";
global.tld2 = "-";
//========== Api Domain 3 ==========//
global.zone3 = "-";
global.apitoken3 = "-";
global.tld3 = "-";
//========== Api Domain 4 ==========//
global.zone4 = "-";
global.apitoken4 = "-";
global.tld4 = "-";

//========= Setting Message =========//
global.msg = {
"error": "Error terjasi kesalahan",
"done": "Berhasil mengambil data ✅", 
"wait": "🕧 Proses, Mohon Tunggu Sebentar Ya puh", 
"group": "Fitur Ini Hanya Untuk Didalam Grup❗", 
"private": "Fitur Ini Hanya Untuk Didalam Private Chat❗", 
"admin": "Fitur Ini Hanya Untuk Admin Grup❗", 
"adminbot": "Fitur Ini Dapat Digunakan Ketika Bot Menjadi Admin❗", 
"owner": "Fitur Ini Hanya Untuk Owner Bot❗", 
"developer": "Fitur Ini Hanya Untuk Developer❗"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})